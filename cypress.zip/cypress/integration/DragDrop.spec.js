describe(`Drag and Drop`, () => {
    function dndNative(source, target, pixel) {
        const dataTransfer = new DataTransfer();
        function inner(obj) {
            cy.get(source).trigger("dragstart", { dataTransfer });
            cy.get(target).trigger("dragover", obj);
            cy.get(target).trigger("drop", { dataTransfer });
            cy.get(source).trigger("dragend");
        }

        if(pixel) {
            cy.get(target).then(($el) => {
                const x1 = $el[0].getBoundingClientRect().left;
                const x2 = $el[0].getBoundingClientRect().width;
                const xc = x1 + x2 / 2;
                const y1 = $el[0].getBoundingClientRect().top;
                const y2 = $el[0].getBoundingClientRect().height;
                const yc = y1 + y2 / 2;
                inner({
                    clientX: xc,
                    clientY: yc,
                });
            });
        } else {
            inner(null);
        }
    }

    function dndMouse(source, target) {
        cy.get(target).then(($el) => {
            const x1 = $el[0].getBoundingClientRect().left;
            const x2 = $el[0].getBoundingClientRect().width;
            const xc = x1 + x2 / 2;
            const y1 = $el[0].getBoundingClientRect().top;
            const y2 = $el[0].getBoundingClientRect().height;
            const yc = y1 + y2 / 2;
            cy.get(source)
              .trigger("mousedown")
              .trigger("mousemove", { clientX: xc, clientY: yc })
              .trigger("mouseup")
        });
    }

    it(`Drag and Drop - HTML Native Drag APIS - Drag Events`, () => {
        // const dataTransfer = new DataTransfer();

        cy.visit("/DragDrop.html");
        // cy.get(".fill").drag("div.empty:nth-of-type(2)");

        // cy.get(".fill").trigger("dragstart", { dataTransfer });
        // cy.get("div.empty:nth-of-type(2)").trigger("drop", { dataTransfer });
        // cy.get(".fill").trigger("draged", { dataTransfer });

        dndNative(".fill", "div.empty:nth-of-type(2)", true);
    })

    it(`External Website seleniumeasy - Drag n Drop`, () => {
        const dataTransfer = new DataTransfer();
        cy.visit("https://www.seleniumeasy.com/test/drag-and-drop-demo.html");

        // cy.get("#todrag>span:nth-child(2)").trigger("dragstart", { dataTransfer });
        // cy.get("#mydropzone").trigger("drop", { dataTransfer });
        // cy.get("#todrag>span:nth-child(2)").trigger("draged", { dataTransfer });

        cy.get("#droppedlist span").contains("Draggable 1").should("be.visible");
    })

    it.only("Drag n Drop - HTML Mouse Events", () => {
        cy.visit("/DragDropMouseEvents.html");

        dndMouse("#divTwo", "#divOne");

        cy.on("window:alert", (text) => {
            expect(text).to.eql("Smaller circle is dropped inside bigger circle");
        });
    })
})