describe('check weather info', () => {
    it('get 1st list', () => {
        cy.request({
            method: 'GET',
            url: 'https://www.metaweather.com/api/location/search/?query=san'
        }).then((res) => {
            expect(res.status).to.eq(200);
            const city = res.body[0].title;
            return city
        }).then((city) => {
            cy.request({
                method: 'GET',
                url: 'https://www.metaweather.com/api/location/search/?query=' + city
            }).then((res) => {
                expect(res.status).to.eq(200);
                expect(res.body[0]).has.property('title', city);
            })
        })
    })

    it.only('get 1st list', () => {
        cy.request({
            method: 'GET',
            url: 'https://www.metaweather.com/api/location/search/?query=Am'
        }).then((res) => {
            expect(res.status).to.eq(200);
            const location = res.body;
            return location
        }).then((location) => {
            for (let index = 0; index < location.length; index++) {
                cy.request({
                    method: 'GET',
                    url: 'https://www.metaweather.com/api/location/search/?query=' + location[index].title
                }).then((res) => {
                    expect(res.status).to.eq(200);
                    expect(res.body[0]).has.property('title', location[index].title);
                })
            }
        })
    })
})