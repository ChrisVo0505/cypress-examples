/// <reference types="cypress" />

describe('get api user tests', () => {

    let accessToken = "924570ff6ff31d8402057987ab6e6deeaefe274ed737bb10e551b8cff899e53d"

    it('get users', () => {
        cy.request({
            method : 'GET',
            url : 'https://gorest.co.in/public/v1/users',
            headers : {
                'authorization' : "Bearer " + accessToken
            }
        }).then((res) => {
            expect(res.status).to.eq(200);
            expect(res.body.meta.pagination.limit).to.eq(20);
        })
    })

    it('get users by id', () => {
        cy.request({
            method : 'GET',
            url : 'https://gorest.co.in/public/v1/users/33',
            headers : {
                'authorization' : "Bearer " + accessToken
            }
        }).then((res) => {
            expect(res.status).to.eq(200);
            expect(res.body.data.name).to.eq('Vidhh');
        })
    })
})