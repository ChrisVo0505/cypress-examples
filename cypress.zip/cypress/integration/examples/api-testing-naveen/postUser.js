describe('post user request', () => {

    let accessToken = "924570ff6ff31d8402057987ab6e6deeaefe274ed737bb10e551b8cff899e53d"
    let randomText = ""
    let testEmail = ""

    it('create user', () => {

        var pattern = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        for(var i = 0; i < 10; i++)
        randomText += pattern.charAt(Math.floor(Math.random() * pattern.length))
        testEmail = randomText + '@gmail.com'

        cy.fixture("api-testing-naveen-userData", (payload) => {

            cy.request({
                method: 'POST',
                url: 'https://gorest.co.in/public/v1/users',
                headers: {
                    'authorization' : "Bearer " + accessToken
                },
                body: {
                    "name": payload.name,
                    "gender": payload.gender,
                    "email": testEmail,
                    "status": payload.status
                }
            }).then((res) => {
                cy.log(JSON.stringify(res)); //convert json to string and display log
                expect(res.status).to.eq(201);
                expect(res.body.data).has.property('email', testEmail);
                expect(res.body.data).has.property('name', payload.name);
                expect(res.body.data).has.property('gender', payload.gender);
                expect(res.body.data).has.property('status', payload.status);
            }).then((res) => {
                const userID = res.body.data.id;
                cy.request({
                    method: 'GET',
                    url: 'https://gorest.co.in/public/v1/users/' + userID,
                    headers: {
                        'authorization' : "Bearer " + accessToken
                    }
                }).then((res) => {
                    expect(res.status).to.eq(200);
                    expect(res.body.data).has.property('email', testEmail);
                    expect(res.body.data).has.property('name', payload.name);
                    expect(res.body.data).has.property('gender', payload.gender);
                    expect(res.body.data).has.property('status', payload.status);
                })
            })
        })
    })
})