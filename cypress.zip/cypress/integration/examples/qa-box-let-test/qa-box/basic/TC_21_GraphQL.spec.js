import { expect } from "chai"

const select_user = `{
    users{
      id
      firstName
      lastName
      age
    }
}`

const create_user = `mutation{ 
    createUser(
        options:{
            firstName:"Chriss",
            lastName:"Voaaba",
            age:40
        }
    ){
        id
        firstName
        lastName
        age
    }
}`

const update_user = `mutation{
    updateUser(id:1
    input:{
      firstName:"Steven"
    })
}`

describe('Testing GraphQL', function() {

    it.only('Select User', function() {
        cy.request({
            method: 'POST',
            url: 'http://localhost:4000/graphql',
            body: {
                query: `{
                    users{
                      id
                      firstName
                      lastName
                      age
                    }
                }`
            }
        }).then(res => {
            expect(res.status).to.eq(200);
            console.log(res.body.data);
            const userName = res.body.data.users[13].firstName;
            expect(userName).to.eq('Allie2');
            console.log(userName);
            return userName
        })
    })

    it('Mutation - Create User', function() {
        cy.request({
            method: 'POST',
            url: 'http://localhost:4000/graphql',
            body: {
                query: `mutation createUser ($firstName: String!, $lastName: String!,  $age: Int!){ 
                    createUser(
                        options:{
                            firstName:$firstName,
                            lastName:$lastName,
                            age:$age
                        }
                    ){
                        id
                        firstName
                        lastName
                        age
                    }
                }`,
                variables: {
                    firstName: `Chris699a`,
                    lastName: `Vo699`,
                    age: 60,
                },
            }
        }).then(res => {
            expect(res.status).to.eq(200);
            expect(res.body.data.createUser.firstName).to.eq(`Chris699a`);
            console.log(res.body)
        })
    })
})