import { Given , And , Then , When, Before} from "cypress-cucumber-preprocessor/steps";
import LoginPage from "../../../../support/page-objects/LoginPage";

let userName
beforeEach(function () {
    cy.request({
        method: 'POST',
        url: 'http://localhost:4000/graphql',
        body: {
            query: `{
                users{
                  id
                  firstName
                  lastName
                  age
                }
            }`
        }
    }).then(res => {
        expect(res.status).to.eq(200);
        console.log(res.body.data);
        userName = res.body.data.users[13].firstName;
        expect(userName).to.eq('Allie2');
        console.log(userName);
        //return userName
    })
});

const loginPage = new LoginPage();

//test steps
When('Go to Login Page', () => {
    cy.visit("/signin");
})

And('Username is wrong', () => {
    loginPage.getUserName().type(userName);
})

And('Password is {string}', (password) => {
    loginPage.getPassword().type(password);
})

And('User click Signin button', () => {
    loginPage.getSubmitButton().click();
})

Then ('I should go to Home Page' , () => {
    cy.location("pathname").should("equal", "/");
})
