import { Given , And , Then , When} from "cypress-cucumber-preprocessor/steps";


//test steps
Given('I go to the Signin Page', () => {
    cy.visit("/");
})

And('I input the Username as {string}', (username) => {
    cy.getBySel("signin-username").type(username);
})

And('I input the Password as {string}', (password) => {
    cy.getBySel("signin-password").type(password);
})

And('I click Sign In button', () => {
    cy.getBySel("signin-submit").click();
})

Then ('I should go to Home Page' , () => {
    cy.getBySel("sidenav-username").contains("Katharina_Bernier");
})