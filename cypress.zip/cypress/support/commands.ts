import "cypress-file-upload";
import "@4tw/cypress-drag-drop";
import "@percy/cypress";
// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

Cypress.Commands.add("getBySel", (selector, ...args) => {
    return cy.get(`[data-test=${selector}]`, ...args);
});

// Login Programmatically by QA BOX LET TEST - TC_20_Login_Programmatically.spec
Cypress.Commands.add("loginViaUI", (username, password) => {
    cy.visit("/")
    cy.get("input#username").type(username)
    cy.get("input#password").type(password)
    cy.get("button#submit").click()
})

Cypress.Commands.add("loginViaAPI", (uname, pwd) => {
    cy.request({
        method: "POST",
        url: Cypress.env("apiserver") + "/login",
        body: {
            username: uname,
            password: pwd
        }
    }).then(res => {
        expect(res.status).to.eq(200)
        window.localStorage.setItem("token", JSON.stringify(res.body))
    })
})

Cypress.Commands.add("loginViaUISession", (username, password) => {
    cy.session([username, password], () => {
        cy.visit("/")
        cy.get("input#username").type(username)
        cy.get("input#password").type(password)
        cy.get("button#submit").click()
        cy.get("#logout").should("be.enabled")
    },
        {
            validate() {
                cy.visit("/home")
                cy.get("#home").should("be.enabled")
            }
        }
    )
})

Cypress.Commands.add("loginViaAPISession", (uname, pwd) => {
    cy.session([uname, pwd], () => {
        cy.request({
            method: 'POST',
            url: Cypress.env('apiUrl') + "/login",
            body: {
                username: uname,
                password: pwd
            }
        }).then(res => {
            expect(res.status).to.eq(200)
            window.localStorage.setItem("authState", JSON.stringify(res.body))
        })
    },
        {
            validate() {
                cy.visit("/")
                cy.location("pathname").should("equal", "/");
            }
        }
    )
})


// ***********************************************
// Commands from chris-castillo examples

Cypress.Commands.add('interceptGraphQl', opName => {
    cy.intercept('POST', 'insertURL', req => {
        const {
            operationName
        } = JSON.parse(req.body);
        if (operationName === opName) {
            console.log(operationName);
            req.alias = opName;
        }
    });
});

Cypress.Commands.add('requestGraphQl', operationName => {
    cy.request({
        url: '/',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: {
            query: operationName
        },
        failOnStatusCode: false
    });
});

let LOCAL_STORAGE = {};

Cypress.Commands.add('saveLocalStorage', () => {
    Cypress.log({
        message: 'Grabbing local storage and saving to variable.',
        displayName: 'SaveLocal'
    });
    Object.keys(localStorage).forEach(key => {
        LOCAL_STORAGE[key] = localStorage[key];
    });
});

Cypress.Commands.add('restoreLocalStorage', () => {
    Cypress.log({
        message: 'Grabbing local storage variable and setting.',
        displayName: 'SetLocal'
    });
    Object.keys(LOCAL_STORAGE).forEach(key => {
        localStorage.setItem(key, LOCAL_STORAGE[key]);
    });
});

const email = Cypress.env('email');
const password = Cypress.env('password');

Cypress.Commands.add('login', () => {
    cy.visit('https://react-redux.realworld.io/#/?_k=d2t9lf');
    cy.get('a[href="#login"]').click();
    cy.get('input[type=email]').type(email);
    cy.get('input[type=password]').type(password);
    cy.get('button').click();
});

Cypress.Commands.add('getAndSetToken', () => {
    Cypress.log({
        message: 'Requests token and sets in local storage.',
        displayName: 'GetToken'
    });
    cy.request({
        url: 'https://conduit.productionready.io/api/users/login',
        method: 'POST',
        body: {
            user: {
                email,
                password
            }
        }
    }).then(response => {
        const {
            token
        } = response.body.user;
        localStorage.setItem('jwt', token);
    });
});

Cypress.Commands.add('seedLocalStorage', (key, value) => {
    // Cypress.log takes an 'options' object
    Cypress.log({
        // $el: jQuery element for the command if it exists
        name: 'seedLocalStorage',
        displayName: 'seedLs',
        message: `key: ${key}, value: ${value}`,
        consoleProps: () => {
            return {
                'Key': key,
                'Value': value,
                'Local Storage': window.localStorage
            }
        }
    });

    localStorage.setItem(key, value);
});

Cypress.Commands.add('getDataTag', value => {
    return cy.get(`[data-cy=${value}]`);
});

Cypress.Commands.add('customFormCommand', ({
    firstName,
    lastName,
    email,
    number,
    subject
}) => {
    // First Name
    cy.getDataTag('first-name')
        .clear()
        .type(firstName);
    // Last Name
    cy.getDataTag('last-name')
        .clear()
        .type(lastName);
    // Email
    cy.getDataTag('email')
        .clear()
        .type(email);
    // Number
    cy.getDataTag('number')
        .clear()
        // @ts-ignore
        .type(number);
    // Subject
    cy.getDataTag('subject-area')
        .clear()
        .type(subject);
});