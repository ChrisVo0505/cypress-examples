class LoginPage {
    getUserName() {
        return cy.get('#username');
    }
    getPassword(){
        return cy.get('#password');
    }
    getSubmitButton() {
        return cy.get('button[type="submit"]');
    }
    loginViaUISession() {
        cy.session([username, password], () => {
            cy.visit('/signin');
            this.getUserName().type(username);
            this.getPassword().type(password);
            this.getSubmitButton().click();
            this.getSubmitButton().should("be.enabled")
        },
            {
                validate() {
                    cy.location("pathname").should("equal", "/");
                }
            }
        )
    }
}

export default LoginPage